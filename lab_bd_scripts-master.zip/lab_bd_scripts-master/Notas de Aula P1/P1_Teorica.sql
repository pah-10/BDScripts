1 c
2 c
3 b c
4 c
5 d
6 c
7 ac
8 ad
9 c
10 a
11 b
12 b
13 d
14 c
15 b
16 e
17 bde
18 a