1 - A
2 - A, C, D