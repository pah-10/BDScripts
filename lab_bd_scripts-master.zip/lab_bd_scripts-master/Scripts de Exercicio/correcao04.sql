1 - B
2 - A, C
3 - B, E
4 - A, D
5 - D
6 - B, D
7 - B, D
8 - D
9 - B
10 - D
11 - C
12 - B
13 - C
14 - B
15 - A, D
16 - A, C, D, E

-- REVISÃO PRA P1

ACERTOS: 1,2,3,4,6,7,8,9,10,12,14
ERROS: 5, 11, 13, 16